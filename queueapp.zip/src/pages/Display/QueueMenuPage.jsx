import TestServiceSelection from "../../components/Display/TestServiceSelection"
// import ServiceSelection from "../../components/Display/ServiceSelection"

const QueueMenuPage = () => {
  return (
    <>
      <TestServiceSelection/>
      {/* Atas Data dengan API bawah Data Static */}
      {/* <ServiceSelection/> */}
    </>
  )
}

export default QueueMenuPage
