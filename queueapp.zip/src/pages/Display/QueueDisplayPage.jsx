import TestQueueDisplay from "../../components/Display/TestQueueDisplay"
// import QueueDisplay from "../../components/Display/QueueDisplay"

const QueueDisplayPage = () => {
  return (
    <>
    <TestQueueDisplay/>
    {/* Atas Data dengan API bawah Data Static */}
    {/* <QueueDisplay/> */}
    </>
  )
}

export default QueueDisplayPage
