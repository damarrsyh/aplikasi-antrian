import TestQueueTable from "../../components/Admin/TestQueueTable";
// import QueueTable from "../../components/Admin/QueueTable";
// import TestComponent from "../../components/test";

const QueueListPage = () => {

  return (
    <div>
      
      <TestQueueTable/>
      {/* Atas Data dengan API bawah Data Static */}
      {/* <QueueTable/>
      <TestComponent/> */}
    </div>
  );
};

export default QueueListPage;
