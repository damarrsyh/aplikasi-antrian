import TestQueueTable from "../../components/Admin/TestQueueTable";

const CallQueuePage = () => {
  return (
    <div>
      <h2>Panggil Atrian Page</h2>
      <TestQueueTable/>
    </div>
  )
}

export default CallQueuePage
